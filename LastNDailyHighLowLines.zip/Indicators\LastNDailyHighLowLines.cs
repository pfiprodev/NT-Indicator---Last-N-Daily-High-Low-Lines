#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.DrawingTools;
using System.Windows.Media;
#endregion

namespace NinjaTrader.NinjaScript.Indicators
{
    public class LastNDailyHighLowLines : Indicator
    {
        private double[] dayHighs;
        private double[] dayLows;
        private DateTime[] dayDates;

        [NinjaScriptProperty]
        [Range(1, 20)]
        [Display(Name = "DaysToShow", Order = 1, GroupName = "Parameters")]
        public int DaysToShow { get; set; } = 5;

        [NinjaScriptProperty]
        [Display(Name = "HighLineBrush", Order = 2, GroupName = "Parameters")]
        public Brush HighLineBrush { get; set; } = Brushes.DodgerBlue;

        [NinjaScriptProperty]
        [Display(Name = "LowLineBrush", Order = 3, GroupName = "Parameters")]
        public Brush LowLineBrush { get; set; } = Brushes.OrangeRed;

        [NinjaScriptProperty]
        [Range(1, 5)]
        [Display(Name = "LineWidth", Order = 4, GroupName = "Parameters")]
        public int LineWidth { get; set; } = 1;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name                     = "LastNDailyHighLowLines";
                Description              = "Draws horizontal lines at the daily high/low for the last N sessions.";
                Calculate                = Calculate.OnEachTick;   // live updates as today's high/low changes
                IsOverlay                = true;
                DisplayInDataBox         = false;
                IsSuspendedWhileInactive = true;
            }
            else if (State == State.DataLoaded)
            {
                dayHighs = new double[DaysToShow];
                dayLows  = new double[DaysToShow];
                dayDates = new DateTime[DaysToShow];

                for (int i = 0; i < DaysToShow; i++)
                {
                    dayHighs[i] = double.NaN;
                    dayLows[i]  = double.NaN;
                    dayDates[i] = DateTime.MinValue;
                }
            }
            else if (State == State.Historical)
            {
                ClearExistingLines();
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < 1)
            {
                dayHighs[0] = High[0];
                dayLows[0]  = Low[0];
                dayDates[0] = Times[0][0].Date;
                DrawAllLines();
                return;
            }

            // New session/day detected
            if (Bars.IsFirstBarOfSession)
            {
                ShiftDaysRight();
                dayHighs[0] = High[0];
                dayLows[0]  = Low[0];
                dayDates[0] = Times[0][0].Date;
                DrawAllLines();
                return;
            }

            // Update today's high/low in real time
            dayHighs[0] = Math.Max(dayHighs[0], High[0]);
            dayLows[0]  = Math.Min(dayLows[0],  Low[0]);

            DrawAllLines();
        }

        private void ShiftDaysRight()
        {
            for (int i = DaysToShow - 1; i >= 1; i--)
            {
                dayHighs[i] = dayHighs[i - 1];
                dayLows[i]  = dayLows[i - 1];
                dayDates[i] = dayDates[i - 1];
            }

            dayHighs[0] = double.NaN;
            dayLows[0]  = double.NaN;
            dayDates[0] = DateTime.MinValue;
        }

        private void DrawAllLines()
        {
            // Clean up any lines beyond DaysToShow (in case user changes setting)
            for (int i = DaysToShow; i < 25; i++)
            {
                RemoveDrawObject($"DHigh_{i}");
                RemoveDrawObject($"DLow_{i}");
            }

            for (int i = 0; i < DaysToShow; i++)
            {
                if (dayDates[i] == DateTime.MinValue ||
                    double.IsNaN(dayHighs[i]) ||
                    double.IsNaN(dayLows[i]))
                    continue;

                string highTag = $"DHigh_{i}";
                string lowTag  = $"DLow_{i}";

                // HorizontalLine extends infinitely left/right (so it will always be visible going forward)
                var highLine = Draw.HorizontalLine(this, highTag, dayHighs[i], HighLineBrush);
                var lowLine  = Draw.HorizontalLine(this, lowTag,  dayLows[i],  LowLineBrush);

                // Width works universally
                highLine.Stroke.Width = LineWidth;
                lowLine.Stroke.Width  = LineWidth;
            }
        }

        private void ClearExistingLines()
        {
            for (int i = 0; i < 25; i++)
            {
                RemoveDrawObject($"DHigh_{i}");
                RemoveDrawObject($"DLow_{i}");
            }
        }
    }
}


#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private LastNDailyHighLowLines[] cacheLastNDailyHighLowLines;
		public LastNDailyHighLowLines LastNDailyHighLowLines(int daysToShow, Brush highLineBrush, Brush lowLineBrush, int lineWidth)
		{
			return LastNDailyHighLowLines(Input, daysToShow, highLineBrush, lowLineBrush, lineWidth);
		}

		public LastNDailyHighLowLines LastNDailyHighLowLines(ISeries<double> input, int daysToShow, Brush highLineBrush, Brush lowLineBrush, int lineWidth)
		{
			if (cacheLastNDailyHighLowLines != null)
				for (int idx = 0; idx < cacheLastNDailyHighLowLines.Length; idx++)
					if (cacheLastNDailyHighLowLines[idx] != null && cacheLastNDailyHighLowLines[idx].DaysToShow == daysToShow && cacheLastNDailyHighLowLines[idx].HighLineBrush == highLineBrush && cacheLastNDailyHighLowLines[idx].LowLineBrush == lowLineBrush && cacheLastNDailyHighLowLines[idx].LineWidth == lineWidth && cacheLastNDailyHighLowLines[idx].EqualsInput(input))
						return cacheLastNDailyHighLowLines[idx];
			return CacheIndicator<LastNDailyHighLowLines>(new LastNDailyHighLowLines(){ DaysToShow = daysToShow, HighLineBrush = highLineBrush, LowLineBrush = lowLineBrush, LineWidth = lineWidth }, input, ref cacheLastNDailyHighLowLines);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.LastNDailyHighLowLines LastNDailyHighLowLines(int daysToShow, Brush highLineBrush, Brush lowLineBrush, int lineWidth)
		{
			return indicator.LastNDailyHighLowLines(Input, daysToShow, highLineBrush, lowLineBrush, lineWidth);
		}

		public Indicators.LastNDailyHighLowLines LastNDailyHighLowLines(ISeries<double> input , int daysToShow, Brush highLineBrush, Brush lowLineBrush, int lineWidth)
		{
			return indicator.LastNDailyHighLowLines(input, daysToShow, highLineBrush, lowLineBrush, lineWidth);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.LastNDailyHighLowLines LastNDailyHighLowLines(int daysToShow, Brush highLineBrush, Brush lowLineBrush, int lineWidth)
		{
			return indicator.LastNDailyHighLowLines(Input, daysToShow, highLineBrush, lowLineBrush, lineWidth);
		}

		public Indicators.LastNDailyHighLowLines LastNDailyHighLowLines(ISeries<double> input , int daysToShow, Brush highLineBrush, Brush lowLineBrush, int lineWidth)
		{
			return indicator.LastNDailyHighLowLines(input, daysToShow, highLineBrush, lowLineBrush, lineWidth);
		}
	}
}

#endregion
